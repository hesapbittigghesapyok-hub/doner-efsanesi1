Doner Efsanevi V11 - Gercek Et Dususu + Foto Referanslari

- Doner kesimindeki selector hatasi duzeltildi (.doner -> .meat)
- Kesim bitince etler otomatik olarak donerin altindaki tepsiye duser.
- Kullanici mouse ile dokunmak zorunda degil.
- Gonderilen metal et tepsisi fotografi oyuna eklendi.
- Gonderilen doner kesme fotografi proje icine referans olarak eklendi.
- Bircok et parcasi tepside birikir.
